"""The unchanged data_rules package must work on MySQL. Only its public functions are used."""
import pytest
from sqlalchemy.dialects import mysql
from sqlalchemy.schema import CreateTable

from app import create_app
from data_rules import DataRulesError
from data_rules.models import Base, RuleRow
from data_rules.seed import load_rule_files, seed_database

from .conftest import MYSQL_URL


def test_every_table_compiles_for_mysql():
    ddl = {t.name: str(CreateTable(t).compile(dialect=mysql.dialect())) for t in Base.metadata.sorted_tables}
    assert set(ddl) == {"user", "item", "region", "rule", "classification_result"}
    assert "FOREIGN KEY(region_code) REFERENCES region (code)" in ddl["rule"]
    assert "CHECK (confidence >= 0 AND confidence <= 1)" in ddl["classification_result"]


def test_all_rule_texts_fit_the_columns():
    """MySQL in strict mode refuses text that is too long, so check the real rule files."""
    bin_max = RuleRow.__table__.c.bin.type.length
    reason_max = RuleRow.__table__.c.reason.type.length
    for data in load_rule_files():
        for rule in data["rules"]:
            assert len(rule["bin"]) <= bin_max and len(rule["reason"]) <= reason_max


def test_dortmund_is_loaded_with_three_rules(dal):
    assert dal.list_regions() == [("DO", "Dortmund")]
    assert [r.category for r in dal.get_rules("DO")] == ["compostable", "landfill", "recyclable"]


def test_seed_twice_does_not_duplicate(dal):
    seed_database(dal)
    seed_database(dal)
    assert len(dal.get_rules("DO")) == 3


def test_utf8_text_survives_the_round_trip(dal):
    dal.save_result("Café-Becher ♻ Müll", "landfill", 0.7, "DO")
    assert dal.get_results()[0].item == "café-becher ♻ müll"


def test_scans_come_back_in_filter_order(dal):
    dal.save_result("a", "landfill", 0.5, "DO")
    dal.save_result("b", "landfill", 0.5, "DO")
    assert [r.item for r in dal.get_results(region_code="DO")] == ["a", "b"]


@pytest.mark.parametrize("item, category, confidence, region", [
    ("can", "metal", 0.9, "DO"),
    ("can", "recyclable", 1.5, "DO"),
    ("can", "recyclable", 0.9, "XX"),
    ("  ", "recyclable", 0.9, "DO"),
])
def test_bad_input_is_refused(dal, item, category, confidence, region):
    with pytest.raises(DataRulesError):
        dal.save_result(item, category, confidence, region)


def test_unknown_region_gives_fallback(rules):
    assert rules.get_rule("landfill", "XX").bin


@pytest.mark.skipif(not MYSQL_URL, reason="set TEST_MYSQL_URL to run the MySQL tests")
def test_data_survives_an_app_restart():
    from data_rules.database import make_engine
    engine = make_engine(MYSQL_URL)
    Base.metadata.drop_all(engine)
    engine.dispose()

    first = create_app({"DATABASE_URL": MYSQL_URL, "DB_WAIT_ATTEMPTS": 1})
    first.extensions["dal"].save_result("glass bottle", "recyclable", 0.95, "DO")
    first.extensions["engine"].dispose()

    second = create_app({"DATABASE_URL": MYSQL_URL, "DB_WAIT_ATTEMPTS": 1})   # "restart"
    assert len(second.extensions["dal"].get_results()) == 1
    assert len(second.extensions["dal"].get_rules("DO")) == 3                 # seed added nothing
    second.extensions["engine"].dispose()
