def test_health_reports_database_ok(client):
    r = client.get("/health")
    assert r.status_code == 200 and r.get_json()["database"] == "reachable"


def test_home_page_shows_data_from_the_database(client):
    html = client.get("/").get_data(as_text=True)
    assert "Dortmund" in html and "Show rules" in html


def test_rules_page_lists_the_three_bins(client):
    html = client.get("/rules/DO").get_data(as_text=True)
    assert "Brown bin" in html and "Grey bin" in html and "Yellow bin" in html


def test_rules_redirects_to_the_default_region(client):
    r = client.get("/rules")
    assert r.status_code == 302 and r.headers["Location"].endswith("/rules/DO")


def test_unknown_region_page_is_404(client):
    assert client.get("/rules/XX").status_code == 404
    assert client.get("/no-such-page").status_code == 404


def test_check_page_answers(client):
    html = client.get("/check?region=DO&category=compostable").get_data(as_text=True)
    assert "Brown bin (Biotonne)" in html


def test_check_page_with_bad_category_shows_an_error_not_a_crash(client):
    r = client.get("/check?region=DO&category=metal")
    assert r.status_code == 200 and "category must be one of" in r.get_data(as_text=True)


def test_adding_a_scan_in_the_form_shows_it_in_the_table(client):
    r = client.post("/scans", data={"item": "tea bag", "category": "compostable",
                                    "confidence": "0.85", "region": "DO"}, follow_redirects=True)
    html = r.get_data(as_text=True)
    assert "Scan saved." in html and "tea bag" in html and "85%" in html


def test_form_with_bad_confidence_is_refused(client):
    r = client.post("/scans", data={"item": "tea bag", "category": "compostable",
                                    "confidence": "abc", "region": "DO"}, follow_redirects=True)
    assert "Could not save" in r.get_data(as_text=True)
    assert client.get("/api/scans").get_json() == []


def test_html_is_escaped(client):
    client.post("/scans", data={"item": "<script>alert(1)</script>", "category": "landfill",
                                "confidence": "0.5", "region": "DO"})
    html = client.get("/scans").get_data(as_text=True)
    assert "<script>alert(1)</script>" not in html and "&lt;script&gt;" in html


# ---- JSON API

def test_api_regions_and_rules(client):
    assert client.get("/api/regions").get_json() == [{"code": "DO", "name": "Dortmund"}]
    rules = client.get("/api/rules/do").get_json()
    assert {r["category"] for r in rules} == {"recyclable", "compostable", "landfill"}
    one = client.get("/api/rules/DO/landfill").get_json()
    assert "Grey" in one["bin"]


def test_api_errors_are_json(client):
    assert client.get("/api/rules/XX").status_code == 404
    assert client.get("/api/rules/DO/metal").status_code == 400
    assert client.get("/api/nothing").get_json() == {"error": "not found"}
    assert client.get("/api/scans?limit=abc").status_code == 400


def test_api_create_and_list_scans(client):
    r = client.post("/api/scans", json={"item": "Glass Jar", "category": "recyclable",
                                        "confidence": 0.91, "region": "DO"})
    assert r.status_code == 201 and r.get_json()["id"] >= 1
    [scan] = client.get("/api/scans?region=DO").get_json()
    assert scan["item"] == "glass jar" and scan["confidence"] == 0.91 and "T" in scan["created_at"]


def test_api_rejects_bad_scans(client):
    assert client.post("/api/scans", data="not json").status_code == 400
    assert client.post("/api/scans", json={"item": "x", "category": "metal",
                                           "confidence": 0.5, "region": "DO"}).status_code == 400
    assert client.post("/api/scans", json={"item": "x", "category": "landfill",
                                           "confidence": "high", "region": "DO"}).status_code == 400
