"""Every test runs twice: on in-memory SQLite (always) and on a real MySQL.

The MySQL run needs a throw-away database. Point TEST_MYSQL_URL at it, for example
  TEST_MYSQL_URL="mysql+pymysql://waste:waste_pw@127.0.0.1:3306/waste_rules_test?charset=utf8mb4"
Without that variable the MySQL runs are skipped. The tables are dropped before each test.
"""
import os
import sys
from pathlib import Path

import pytest
from sqlalchemy.pool import StaticPool

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import create_app  # noqa: E402  (also puts data_rules/src on the path)
from data_rules.database import make_engine  # noqa: E402
from data_rules.models import Base  # noqa: E402

MYSQL_URL = os.environ.get("TEST_MYSQL_URL")


@pytest.fixture(params=["sqlite", "mysql"])
def app(request):
    if request.param == "sqlite":
        config = {
            "DATABASE_URL": "sqlite://",
            "ENGINE_OPTIONS": {"poolclass": StaticPool, "connect_args": {"check_same_thread": False}},
        }
    else:
        if not MYSQL_URL:
            pytest.skip("set TEST_MYSQL_URL to run the MySQL tests")
        engine = make_engine(MYSQL_URL)
        Base.metadata.drop_all(engine)
        engine.dispose()
        config = {"DATABASE_URL": MYSQL_URL}
    config.update(TESTING=True, DB_WAIT_ATTEMPTS=1)
    flask_app = create_app(config)
    yield flask_app
    flask_app.extensions["engine"].dispose()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def dal(app):
    return app.extensions["dal"]


@pytest.fixture
def rules(app):
    return app.extensions["rules"]
