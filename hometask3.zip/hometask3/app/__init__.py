"""Flask pages and a small JSON API on top of the Data & Rules subsystem (data_rules).

The data_rules package is used exactly as the team wrote it. Nothing in it is copied or changed here.
It is found through the same PYTHONPATH convention as in the root Dockerfile (data_rules/src).
"""
import logging
import os
import sys
import time
from pathlib import Path

# repo root = hometask3/app/__init__.py -> parents[2]
_DATA_RULES_SRC = Path(__file__).resolve().parents[2] / "data_rules" / "src"
if _DATA_RULES_SRC.is_dir() and str(_DATA_RULES_SRC) not in sys.path:
    sys.path.insert(0, str(_DATA_RULES_SRC))

from flask import Flask  # noqa: E402
from sqlalchemy import text  # noqa: E402
from sqlalchemy.exc import OperationalError  # noqa: E402

from data_rules import DataAccessLayer, RuleEngine  # noqa: E402
from data_rules.database import init_db, make_engine, make_session_factory  # noqa: E402
from data_rules.seed import seed_database  # noqa: E402

from .config import database_url, default_region  # noqa: E402


def wait_for_database(engine, attempts: int = 30, delay: float = 2.0) -> None:
    """Block until MySQL answers. In Docker, MySQL starts a bit later than the app."""
    last_error = None
    for _ in range(max(1, attempts)):
        try:
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            return
        except OperationalError as exc:
            last_error = exc
            time.sleep(delay)
    raise RuntimeError(f"database not reachable after {attempts} attempts") from last_error


def create_app(test_config: dict | None = None) -> Flask:
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY", "dev-only-change-me"),   # needed for the flash messages
        DATABASE_URL=None,          # None = build the MySQL URL from the MYSQL_* variables
        DB_WAIT_ATTEMPTS=30,
        ENGINE_OPTIONS={},
        DEFAULT_REGION=default_region(),
    )
    if test_config:
        app.config.update(test_config)

    logging.basicConfig(level=logging.INFO)

    options = dict(app.config["ENGINE_OPTIONS"])
    url = app.config["DATABASE_URL"] or database_url()
    if not url.startswith("sqlite"):
        # MySQL closes idle connections after a while. These settings reconnect quietly.
        options.setdefault("pool_pre_ping", True)
        options.setdefault("pool_recycle", 280)
    engine = make_engine(url, **options)             # data_rules.database.make_engine
    wait_for_database(engine, attempts=app.config["DB_WAIT_ATTEMPTS"])
    init_db(engine)                                  # creates the five tables if they are missing
    dal = DataAccessLayer(make_session_factory(engine))
    seed_database(dal)                               # loads rules/*.json, safe to run on every start

    app.extensions["engine"] = engine
    app.extensions["dal"] = dal
    app.extensions["rules"] = RuleEngine(dal)

    from .routes import bp
    app.register_blueprint(bp)

    @app.cli.command("seed")
    def seed_command():
        """Load the rule files into MySQL (safe to run many times)."""
        seed_database(dal)
        print("Database seeded.")

    return app
