"""Settings. Everything that can change between machines comes from environment variables."""
import os

from sqlalchemy.engine import URL


def database_url() -> str:
    """The MySQL connection, built from MYSQL_* variables.

    DATABASE_URL, if set, wins. The tests use it to switch to an in-memory SQLite database.
    """
    explicit = os.environ.get("DATABASE_URL")
    if explicit:
        return explicit
    url = URL.create(
        "mysql+pymysql",
        username=os.environ.get("MYSQL_USER", "waste"),
        password=os.environ.get("MYSQL_PASSWORD", "waste_pw"),
        host=os.environ.get("MYSQL_HOST", "127.0.0.1"),
        port=int(os.environ.get("MYSQL_PORT", "3306")),
        database=os.environ.get("MYSQL_DATABASE", "waste_rules"),
        query={"charset": "utf8mb4"},
    )
    return url.render_as_string(hide_password=False)


def default_region() -> str:
    return os.environ.get("DEFAULT_REGION", "DO").upper()
