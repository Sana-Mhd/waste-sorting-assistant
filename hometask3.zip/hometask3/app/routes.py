"""Web pages (HTML) and the JSON API. Both read from MySQL through the data_rules access layer."""
from dataclasses import asdict

from flask import (Blueprint, abort, current_app, flash, jsonify, redirect,
                   render_template, request, url_for)
from sqlalchemy import text

from data_rules import CATEGORIES, DataRulesError

bp = Blueprint("main", __name__)


def dal():
    return current_app.extensions["dal"]


def rules():
    return current_app.extensions["rules"]


def region_name(code: str) -> str | None:
    return dict(dal().list_regions()).get(code.strip().upper())


def recent_scans(limit: int, region: str | None = None):
    """Newest first. data_rules returns oldest first, so the list is reversed here."""
    return list(reversed(dal().get_results(region_code=region)))[:max(1, limit)]


def _record_json(record) -> dict:
    data = asdict(record)
    data["created_at"] = record.created_at.isoformat()
    return data


# ---------------------------------------------------------------- HTML pages

@bp.get("/")
def index():
    regions = [
        {"code": code, "name": name, "rule_count": len(dal().get_rules(code))}
        for code, name in dal().list_regions()
    ]
    return render_template(
        "index.html",
        regions=regions,
        scan_count=len(dal().get_results()),
        recent=recent_scans(5),
    )


@bp.get("/rules")
def rules_default():
    return redirect(url_for("main.rules_page", code=current_app.config["DEFAULT_REGION"]))


@bp.get("/rules/<code>")
def rules_page(code):
    name = region_name(code)
    if name is None:
        abort(404)
    return render_template("rules.html", code=code.upper(), name=name, rules=dal().get_rules(code))


@bp.get("/check")
def check():
    regions = dal().list_regions()
    region = request.args.get("region", current_app.config["DEFAULT_REGION"]).upper()
    category = request.args.get("category", "")
    answer = None
    if category:
        try:
            answer = rules().get_rule(category, region)
        except DataRulesError as exc:
            flash(str(exc), "error")
    return render_template("check.html", regions=regions, categories=CATEGORIES,
                           region=region, category=category, answer=answer)


@bp.route("/scans", methods=["GET", "POST"])
def scans():
    if request.method == "POST":
        try:
            dal().save_result(
                item=request.form.get("item", ""),
                category=request.form.get("category", ""),
                confidence=float(request.form.get("confidence", "")),
                region_code=request.form.get("region", ""),
            )
            flash("Scan saved.", "ok")
        except (DataRulesError, ValueError) as exc:
            flash(f"Could not save: {exc}", "error")
        return redirect(url_for("main.scans", region=request.form.get("region", "")))

    region = request.args.get("region", "").upper() or None
    return render_template(
        "scans.html",
        regions=dal().list_regions(),
        categories=CATEGORIES,
        region=region,
        records=recent_scans(50, region),
        default_region=current_app.config["DEFAULT_REGION"],
    )


# ---------------------------------------------------------------- JSON API

@bp.get("/health")
def health():
    """Answers 200 only if MySQL really answers."""
    try:
        with current_app.extensions["engine"].connect() as conn:
            conn.execute(text("SELECT 1"))
    except Exception:            # any database problem means "not healthy"
        return jsonify(status="error", database="unreachable"), 503
    return jsonify(status="ok", database="reachable")


@bp.get("/api/regions")
def api_regions():
    return jsonify([{"code": c, "name": n} for c, n in dal().list_regions()])


@bp.get("/api/rules/<code>")
def api_rules(code):
    if region_name(code) is None:
        return jsonify(error=f"unknown region {code.upper()!r}"), 404
    return jsonify([asdict(r) for r in dal().get_rules(code)])


@bp.get("/api/rules/<code>/<category>")
def api_rule(code, category):
    if region_name(code) is None:
        return jsonify(error=f"unknown region {code.upper()!r}"), 404
    try:
        return jsonify(asdict(rules().get_rule(category, code)))
    except DataRulesError as exc:
        return jsonify(error=str(exc)), 400


@bp.get("/api/scans")
def api_scans_list():
    region = request.args.get("region") or None
    try:
        limit = int(request.args.get("limit", "50"))
    except ValueError:
        return jsonify(error="limit must be a number"), 400
    return jsonify([_record_json(r) for r in recent_scans(limit, region)])


@bp.post("/api/scans")
def api_scans_create():
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return jsonify(error="send a JSON object"), 400
    try:
        new_id = dal().save_result(
            item=str(body.get("item", "")),
            category=str(body.get("category", "")),
            confidence=float(body.get("confidence", "")),
            region_code=str(body.get("region", "")),
        )
    except (DataRulesError, ValueError, TypeError) as exc:
        return jsonify(error=str(exc)), 400
    return jsonify(id=new_id), 201


@bp.app_errorhandler(404)
def not_found(_error):
    if request.path.startswith("/api/"):
        return jsonify(error="not found"), 404
    return render_template("404.html"), 404
