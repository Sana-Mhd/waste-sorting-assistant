# Hometask 3: Web APIs & Database Access Layers

A small Flask project that shows data from a MySQL database through SQLAlchemy, as web pages and as a JSON API.
It sits on top of the **Data & Rules** subsystem (`data_rules/`) of our capstone project
"AI-Powered Waste Sorting & Recycling Assistant" and uses that code **exactly as it is**.
No file in `data_rules/` or anywhere else in the project was changed for this hometask. This folder only adds to it.

## Identification

| | |
|---|---|
| Name | Fatemeh Hemmati |
| Matriculation number | 7224097 MDT |
| Study program | M.Sc. Digital Transformation, Fachhochschule Dortmund |
| Subsystem | 2: Data & Rules (SQLAlchemy, `data_rules/`) |
| Assignment | Hometask 3. Web APIs & Database Access Layers |

## What it does

| Page | What you see |
|---|---|
| `/` | Number of regions, rules and saved scans, the region list and the five latest scans |
| `/rules/DO` | The recycling rules of Dortmund (bin and reason per category) |
| `/check` | Pick a region and a category, get the bin |
| `/scans` | Table of saved scans, filter by region, form to add a scan |

| JSON endpoint | Answer |
|---|---|
| `GET /health` | `200` only if MySQL answers, otherwise `503` |
| `GET /api/regions` | All regions |
| `GET /api/rules/<region>` | All rules of a region |
| `GET /api/rules/<region>/<category>` | One rule |
| `GET /api/scans?region=DO&limit=20` | Latest scans, newest first |
| `POST /api/scans` | Save a scan. Body: `{"item": "glass jar", "category": "recyclable", "confidence": 0.91, "region": "DO"}` |

Bad input gives a JSON error with status `400` or `404`, never a stack trace.

## Screenshots

![Home](docs/screenshots/1-home.png)
![Rules of Dortmund](docs/screenshots/2-rules.png)
![Which bin](docs/screenshots/3-check.png)
![Scans](docs/screenshots/4-scans.png)
![JSON answer](docs/screenshots/5-api.png)

## How it uses data_rules

`data_rules` already reads its database from a SQLAlchemy URL, so MySQL needs no change in it:
the tables are created from the same models, and the same seed loads `rules/dortmund.json`.
The Flask code calls only the public functions below.

| Needed by the pages | data_rules function |
|---|---|
| Connect, create the tables, load the rules | `make_engine`, `init_db`, `make_session_factory`, `seed_database` |
| Regions and rules | `DataAccessLayer.list_regions`, `get_rules` |
| Which bin | `RuleEngine.get_rule` |
| Save and list scans | `DataAccessLayer.save_result`, `get_results` |
| Errors | `DataRulesError` (shown to the user as a message or a JSON error) |

The five tables are `user`, `item`, `classification_result`, `region` and `rule`.
The ERD is in [`data_rules/docs/erd.png`](../data_rules/docs/erd.png).

## Run it

The folder `hometask3/` must stay next to `data_rules/` (it is in the project root).

### Option A: Docker (MySQL and the app together)

```bash
cd hometask3
docker compose up --build
```

Open http://localhost:5000. The app waits until MySQL is ready, creates the tables and loads the rules.
The data stays in the `mysql-data` volume. Stop with `docker compose down` (add `-v` to delete the data).
This is separate from the main project's `docker compose` (port 8501).

### Option B: without Docker

Python 3.11 or newer and a running MySQL 8 (or MariaDB).

```bash
# 1. database and user (run once, in the mysql client)
CREATE DATABASE waste_rules CHARACTER SET utf8mb4;
CREATE USER 'waste'@'localhost' IDENTIFIED BY 'waste_pw';
GRANT ALL ON waste_rules.* TO 'waste'@'localhost';

# 2. the app, from the project root
cd hometask3
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # adjust the MYSQL_* values if needed
export $(grep -v '^#' .env | xargs)   # Windows: set the variables by hand
python wsgi.py
```

Open http://localhost:5000.

### Settings

All settings are environment variables (see `.env.example`).

| Variable | Default | Meaning |
|---|---|---|
| `MYSQL_HOST`, `MYSQL_PORT` | `127.0.0.1`, `3306` | Where MySQL runs |
| `MYSQL_USER`, `MYSQL_PASSWORD` | `waste`, `waste_pw` | Login |
| `MYSQL_DATABASE` | `waste_rules` | Database name |
| `DEFAULT_REGION` | `DO` | Region the pages open with |
| `DATABASE_URL` | not set | A full SQLAlchemy URL. If set, it replaces the `MYSQL_*` values |

Load the rules by hand at any time with `flask --app wsgi seed`. It can run many times without creating duplicates.

## Files

```
hometask3/
  app/__init__.py   create_app: connects to MySQL, creates the tables, loads the rules
  app/config.py     builds the MySQL URL from environment variables
  app/routes.py     HTML pages and JSON API
  app/templates/    pages
  app/static/       style
  tests/            pytest, runs on SQLite and on MySQL
  Dockerfile, docker-compose.yml, wsgi.py, requirements.txt, .env.example
```

## Tests

```bash
cd hometask3
pip install -r requirements.txt
python -m pytest                    # 25 tests on SQLite, the MySQL runs are skipped

# also on a real MySQL (use an empty throw-away database, its tables are dropped before each test)
export TEST_MYSQL_URL="mysql+pymysql://waste:waste_pw@127.0.0.1:3306/waste_rules_test?charset=utf8mb4"
python -m pytest                    # 49 tests
```

The tests cover every page and every JSON endpoint, bad input, HTML escaping, UTF-8 text, the seed running twice,
that all rule texts fit the MySQL columns, and that data survives an app restart.
I ran them against MariaDB 10.11, which is MySQL compatible. The tests of `data_rules` itself are unchanged
(`cd data_rules && python -m pytest`).

## Known limits

- The scan list reads all scans and cuts the list in Python, because `get_results` has no limit option.
  That is fine for this size. A real deployment would add a `limit` to `data_rules`.
- The form for new scans has no login and no CSRF protection. It is meant for local use.
